using System;
using Xunit;
using FluentAssertions;

namespace TechTest.UnitTests
{
    public class FizzBuzzTests
    {
        [Fact]
        public void FizzBuzz_returns_empty_report_for_0_element_range() =>
            FizzBuzz
                .FromRange(1, 0)
                .Should()
                .Be("fizz: 0 buzz: 0 fizzbuzz: 0 lucky: 0 integer: 0");

        [Fact]
        public void FizzBuzz_returns_correct_result_for_range_1_to_10() =>
            FizzBuzz
                .FromRange(1, 10)
                .Should()
                .Be("1 2 lucky 4 buzz fizz 7 8 fizz buzz fizz: 2 buzz: 2 fizzbuzz: 0 lucky: 1 integer: 5");


        [Fact]
        public void FizzBuzz_returns_correct_result_for_range_1_to_20() =>
            FizzBuzz
                .FromRange(1, 20)
                .Should()
                .Be("1 2 lucky 4 buzz fizz 7 8 fizz buzz 11 fizz lucky 14 fizzbuzz 16 17 fizz 19 buzz fizz: 4 buzz: 3 fizzbuzz: 1 lucky: 2 integer: 10");

    }
}
