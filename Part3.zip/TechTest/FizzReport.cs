namespace TechTest
{
    public class FizzReport
    {
        public FizzReport() {}
        public FizzReport(int fizz, int buzz, int fizzBuzz, int lucky, int integer)
        {
            this.fizz = fizz;
            this.buzz = buzz;
            this.fizzBuzz = fizzBuzz;
            this.lucky = lucky;
            this.integer = integer;
        }
        private int fizz, buzz, fizzBuzz, lucky, integer;

        public FizzReport IncrementFizz() => new FizzReport(fizz + 1, buzz, fizzBuzz, lucky, integer);
        public FizzReport IncrementBuzz() => new FizzReport(fizz, buzz + 1, fizzBuzz, lucky, integer);
        public FizzReport IncrementFizzBuzz() => new FizzReport(fizz, buzz, fizzBuzz + 1, lucky, integer);
        public FizzReport IncrementLucky() => new FizzReport(fizz, buzz, fizzBuzz, lucky + 1, integer);
        public FizzReport IncrementInteger() => new FizzReport(fizz, buzz, fizzBuzz, lucky, integer + 1);

        public override string ToString()
        {
            return $"fizz: {fizz} buzz: {buzz} fizzbuzz: {fizzBuzz} lucky: {lucky} integer: {integer}";
        }
    }
}
