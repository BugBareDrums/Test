﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace TechTest
{
    public static class FizzBuzz
    {
        private static (string output, FizzReport report) SingleFizzBuzz((string output, FizzReport report) accumulator, int value)
        {
            var (output, report) = accumulator;
            if(value.ToString().Contains("3")) return (output + " lucky", report.IncrementLucky());
            if (value % 15 == 0) return (output + " fizzbuzz", report.IncrementFizzBuzz());
            if (value % 3 == 0) return (output + " fizz", report.IncrementFizz());
            if (value % 5 == 0) return (output + " buzz", report.IncrementBuzz());
            return (output + $" {value}", report.IncrementInteger());
        }

        public static string FromRange(int start, int count)
        {
            (string output, FizzReport report) result = Enumerable
                .Range(start, count)
                .Aggregate(("", new FizzReport()), SingleFizzBuzz);

            if(String.IsNullOrEmpty(result.output))
            {
                return result.report.ToString();
            }

            return $"{result.output.Trim()} {result.report}";
        }
    }
}
