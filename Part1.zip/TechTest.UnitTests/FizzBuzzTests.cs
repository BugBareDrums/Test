using System;
using Xunit;
using FluentAssertions;

namespace TechTest.UnitTests
{
    public class FizzBuzzTests
    {
        [Fact]
        public void FizzBuzz_returns_empty_for_0_element_range() =>
            FizzBuzz
                .FromRange(1, 0)
                .Should()
                .Be(string.Empty);

        [Fact]
        public void FizzBuzz_returns_correct_result_for_range_1_to_20() =>
            FizzBuzz
                .FromRange(1, 20)
                .Should()
                .Be("1 2 fizz 4 buzz fizz 7 8 fizz buzz 11 fizz 13 14 fizzbuzz 16 17 fizz 19 buzz");

    }
}
