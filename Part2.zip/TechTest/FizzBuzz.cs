﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TechTest
{


    public static class FizzBuzz
    {
        private static string SingleFizzBuzz(int value)
        {
            if(value.ToString().Contains("3")) return "lucky";
            if (value % 15 == 0) return "fizzbuzz";
            if (value % 3 == 0) return "fizz";
            if (value % 5 == 0) return "buzz";
            return value.ToString();
        }

        public static object FromRange(int start, int count)
        {
            var fizzBuzzList = Enumerable
                    .Range(start, count)
                    .Select(SingleFizzBuzz);

            return String.Join(" ", fizzBuzzList);
        }
    }
}
